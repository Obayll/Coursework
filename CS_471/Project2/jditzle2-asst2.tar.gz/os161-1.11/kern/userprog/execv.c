#include <types.h>
#include <addrspace.h>
#include <curthread.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <kern/limits.h>
#include <lib.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <syscall.h>
#include <thread.h>
#include <vfs.h>
#include <vm.h>

int
sys_execv(const char* program, char** args, int* err) {
	int spl = splhigh();
	
	struct vnode* v;
	struct addrspace *as;
	char **arga, **argm;
	vaddr_t entrypoint, stackptr;
	int retval, argc, i, j;
	size_t actual;
	
    if (argc > ARG_MAX) {
		*err = E2BIG;
		splx(spl);
		return -1;
	}
	
	i = 0;
	while (1) {
		const char* arg = args[i];
		if (!arg) break;
		i++;
	}
	
	char* kpath = (char*)kmalloc(strlen(program) + 1);
	
	if (kpath == NULL) {
		*err = ENOMEM;
		splx(spl);
		return -1;
	}
	
	retval = copyinstr((userptr_t)program, kpath, strlen(program) + 1, &actual);
	
    if (retval) {
        kfree(kpath);
        *err = retval;
		splx(spl);
		return -1;
    }

    if (strlen(kpath) == 0) {
        kfree(kpath);
        *err = EINVAL;
		splx(spl);
		return -1;
    }
	
	argc = i;
	argm = (char**)kmalloc(sizeof(char*));
	if (argm == NULL) {
		kfree(kpath);
		*err = ENOMEM;
		splx(spl);
		return -1;
	}
	
	i = 0;
	for (;i < argc; i++) {
		if (program == NULL || args == NULL) {
			kfree(kpath);
			*err = EFAULT;
			splx(spl);
			return -1;
		}
	}
	
	i = 0;
	for (; i < argc; i++) {
		i = strlen(args[i]) + 1;
		argm[i] = (char*)kmalloc(i);
		copyinstr((userptr_t)args[i], argm[i], i, &actual);
		if (argm[i] == NULL) {
			kfree(kpath);
			*err = ENOMEM;
			splx(spl);
			return -1;
		}
	}
	
	argm[argc] = NULL;
	
	retval = vfs_open(kpath, O_RDONLY, &v);
	if (retval) {
		kfree(kpath);
		*err = retval;
		return -1;
	}
	
	if (curthread->t_vmspace) {
		as = curthread->t_vmspace;
		curthread->t_vmspace = NULL;
		as_destroy(as);
	}
	
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace == NULL) {
		kfree(kpath);
		vfs_close(v);
		*err = ENOMEM;
		return -1;
	}
	
	as_activate(curthread->t_vmspace);
	retval = load_elf(v, &entrypoint);
	if (retval) {
		kfree(kpath);
		vfs_close(v);
		return retval;
	}
	
	vfs_close(v);
	
	retval = as_define_stack(curthread->t_vmspace, &stackptr);
	if (retval) {
		kfree(kpath);
		*err = retval;
		return -1;
	}
	
	arga = (char **) kmalloc(sizeof(char *) * argc + 1);
	
	i = 0;
	j = 0;
	for (i = 0; i < argc ; i++) {
		i = strlen(argm[i]) + 1;
		j = i;
		if (i % 4 != 0) {
			j = i % 4;
			j = (i + (4 - j));
		}
		stackptr -= j;
		copyoutstr(argm[i], (userptr_t)stackptr, i, &actual);
		stackptr += i;
	}
	
	for (i = 0; i < argc + 1; i++) {
        copyout(arga + 1, (userptr_t)stackptr, 4);
		stackptr += 4;
	}
	
	kfree(argm);
	kfree(arga);
	
	splx(spl);
	
	md_usermode(argc, (userptr_t)stackptr, stackptr, entrypoint);
	
	*err = EINVAL;
	return -1;
}
