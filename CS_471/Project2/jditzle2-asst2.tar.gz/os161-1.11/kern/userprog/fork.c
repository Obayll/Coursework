#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <kern/errno.h>
#include <machine/spl.h>
#include <machine/trapframe.h>

static
void
child_fork(void *tf, unsigned long child_addr) {
	int spl = splhigh();
	
	struct trapframe new_tf;
	struct addrspace *new_vm;
	
	// Copy parent's trapframe and free its memory.
	new_tf = *(struct trapframe*)tf;
	kfree(tf);
	
	// Copy parent's address space.
	new_vm = (struct addrspace*)child_addr;
	
	// Copies child address space into current process.
	as_copy(new_vm, &(curthread->t_vmspace));
	
	// Increment process counter.
	md_forkentry(&new_tf);
	splx(spl);
}

int
sys_fork(struct trapframe *tf, int *err) {
	int spl = splhigh();
	
	struct trapframe *child_tf;
	struct addrspace *child_addr;
	struct thread *child_thread;
	
	// Copy parent's trapframe.
	child_tf = kmalloc(sizeof(struct trapframe));
	*child_tf = *tf;
	
	// Copy parent's address space.
	child_addr = kmalloc(sizeof(struct addrspace));
	*child_addr = *(curthread->t_vmspace);
	
	// Set err to 0 if successful operation, -1 if failure.
	*err = thread_fork(curthread->t_name, child_tf, (unsigned long) child_addr, child_fork, &child_thread);
	
	// Return error if any structs are NULL.
	if (child_tf == NULL || child_addr == NULL || child_thread == NULL) return ENOMEM;
	
	// Return child process's pid upon successful run.
	splx(spl);
	return child_thread->pid;
}
