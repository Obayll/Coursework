#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>

pid_t
sys_getpid(void) {
	// Returns current thread's pid.
    return curthread->pid;
}
