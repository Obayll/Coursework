#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <machine/spl.h>

void
sys__exit(int code) { 	
	int spl = splhigh();
	
	// Update current thread's status with given arugment.
	curthread->exit_status = code;
	
	// If parent exists wakeup parent and wait for response before exiting.
	if (curthread->parent_pid != 0 && process_table[curthread->parent_pid] != NULL) {
		thread_wakeup(curthread);
		thread_sleep(curthread);
	}
	
	thread_exit();
	splx(spl);
}
