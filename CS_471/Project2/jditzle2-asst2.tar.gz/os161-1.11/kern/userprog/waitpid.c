#include <types.h>
#include <lib.h>
#include <syscall.h>
#include <thread.h>
#include <machine/spl.h>
#include <kern/errno.h>

pid_t
sys_waitpid(pid_t pid, int *status, int options, int *err) {
	int spl = splhigh();
	
	// Reset error variable.
	*err = 0;
	
	// Only option 0 is supported currently.
	if (options != 0) *err = EINVAL;

	// Check for invalid status pointer and pid.
	if (status == NULL) *err = EFAULT;
	
	// Return if errors are present.
	if (*err) {
		splx(spl);
		return -1;
	}
	
	// Update status variable to current thread status.
	*status = process_table[pid]->exit_status;
	
	// If child has not exited, wakeup child.
	// Else sleep child.
	if (process_table[pid]->exit_status > -1) thread_wakeup(process_table[pid]);
	else thread_sleep(process_table[pid]);
	
	// Thread is allowed to exit.
	thread_wakeup(process_table[pid]);
	splx(spl);
	return pid;
}
