/*
* stoplight.c
*
* 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
*
* NB: You can use any synchronization primitives available to solve
* the stoplight problem in this file.
*/


/*
*
* Includes
*
*/

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h>


/*
*
* Global Variables
*
*/

/*
* Locks for the intersection.
*/

struct lock *NW_Lock;
struct lock *NE_Lock;
struct lock *SW_Lock;
struct lock *SE_Lock;
struct lock *limit_Lock;
struct lock *enter_Lock;

/*
* Maximum amount cars allowed in the intersection.
*/

int carLimit;


/*
*
* Constants
*
*/

/*
* Number of cars created.
*/

#define NCARS 20

/*
* Array of cardinal directions.
*/

static const char *dirArray[] = {"S", "E", "N", "W"};


/*
*
* Function Definitions
*
*/

/*
* incLimit()
*
* Arguments:
*      nothing.
*
* Returns:
*      nothing.
*
* Notes:
*      Function responsible for increasing the global variable carLimit
*      inside the critical section.
*      Allows a maximum of 3 cars in the intersection to avoid
*      deadlocks, excluding right turns.
*      Yields the current thread if the maximum amount of cars are in the
*      intersection to avoid busy waiting.
*      Uses limit_Lock as the lock for the global variable and enter_Lock as
*      the lock for limit_Lock.
*/

static
void
incLimit()
  {
    lock_acquire(enter_Lock);
    while (lock_do_i_hold(enter_Lock)) {
      if (carLimit < 3) {
        lock_acquire(limit_Lock);
        carLimit++;
        lock_release(limit_Lock);
        lock_release(enter_Lock);
      } else thread_yield();
    }
  }

/*
* decLimit()
*
* Arguments:
*      nothing.
*
* Returns:
*      nothing.
*
* Notes:
*      Function responsible for decreasing the global variable carLimit
*      inside the critical section.
*      Uses limit_Lock as the lock for the global variable.
*/

static
void
decLimit()
  {
    lock_acquire(limit_Lock);
    carLimit--;
    lock_release(limit_Lock);
  }

/*
* goStraight()
*
* Arguments:
*      unsigned long cardirection: the direction from which the car
*              approaches the intersection.
*      unsigned long carnumber: the car id number for printing purposes.
*
* Returns:
*      nothing.
*
* Notes:
*      This function should implement passing straight through the
*      intersection from any direction.
*      Write and comment this function.
*/

static
void
goStraight(unsigned long carDirection,
  unsigned long carNumber)
  {
    incLimit();
    switch (carDirection) {
      case 0:
        // Arriving from the south and going straight.
        // Moves from SE -> NE
        lock_acquire(SE_Lock);
        kprintf("Car #%lu enters SE. Step 1 of 3 of straight movement.\n", carNumber);
        lock_acquire(NE_Lock);
        kprintf("Car #%lu moves from SE to NE. Step 2 of 3 of straight movement.\n", carNumber);
        lock_release(SE_Lock);
        kprintf("Car #%lu leaves NE. Step 3 of 3 of straight movement.\n", carNumber);
        lock_release(NE_Lock);
        break;
      case 1:
        // Arriving from the east and going straight.
        // Moves from NE -> NW
        lock_acquire(NE_Lock);
        kprintf("Car #%lu enters NE. Step 1 of 3 of straight movement.\n", carNumber);
        lock_acquire(NW_Lock);
        kprintf("Car #%lu moves from NE to NW. Step 2 of 3 of straight movement.\n", carNumber);
        lock_release(NE_Lock);
        kprintf("Car #%lu leaves NW. Step 3 of 3 of straight movement.\n", carNumber);
        lock_release(NW_Lock);
        break;
      case 2:
        // Arriving from the north and going straight.
        // Moves from NW -> SW
        lock_acquire(NW_Lock);
        kprintf("Car #%lu enters NW. Step 1 of 3 of straight movement.\n", carNumber);
        lock_acquire(SW_Lock);
        kprintf("Car #%lu moves from NW to SW. Step 2 of 3 of straight movement.\n", carNumber);
        lock_release(NW_Lock);
        kprintf("Car #%lu leaves SW. Step 3 of 3 of straight movement.\n", carNumber);
        lock_release(SW_Lock);
        break;
      case 3:
        // Arriving from the west and going straight.
        // Moves from SW -> SE
        lock_acquire(SW_Lock);
        kprintf("Car #%lu enters SW. Step 1 of 3 of straight movement.\n", carNumber);
        lock_acquire(SE_Lock);
        kprintf("Car #%lu moves from SW to SE. Step 2 of 3 of straight movement.\n", carNumber);
        lock_release(SW_Lock);
        kprintf("Car #%lu leaves SE. Step 3 of 3 of straight movement.\n", carNumber);
        lock_release(SE_Lock);
        break;
      default: break;
    }
    decLimit();
  }

/*
* turnLeft()
*
* Arguments:
*      unsigned long cardirection: the direction from which the car
*              approaches the intersection.
*      unsigned long carnumber: the car id number for printing purposes.
*
* Returns:
*      nothing.
*
* Notes:
*      This function should implement making a left turn through the
*      intersection from any direction.
*      Write and comment this function.
*/

static
void
turnLeft(unsigned long carDirection,
  unsigned long carNumber)
  {
    incLimit();
    switch (carDirection) {
      case 0:
        // Arriving from the south and turning left.
        // Moves from SE -> NE -> NW
        lock_acquire(SE_Lock);
        kprintf("Car #%lu enters SE. Step 1 of 4 of left turn.\n", carNumber);
        lock_acquire(NE_Lock);
        kprintf("Car #%lu moves from SE to NE. Step 2 of 4 of left turn.\n", carNumber);
        lock_release(SE_Lock);
        lock_acquire(NW_Lock);
        kprintf("Car #%lu moves from NE to NW. Step 3 of 4 of left turn.\n", carNumber);
        lock_release(NE_Lock);
        kprintf("Car #%lu leaves NW. Step 4 of 4 of left turn.\n", carNumber);
        lock_release(NW_Lock);
        break;
      case 1:
        // Arriving from the east and turning left.
        // Moves from NE -> NW -> SW
        lock_acquire(NE_Lock);
        kprintf("Car #%lu enters NE. Step 1 of 4 of left turn.\n", carNumber);
        lock_acquire(NW_Lock);
        kprintf("Car #%lu moves from NE to NW. Step 2 of 4 of left turn.\n", carNumber);
        lock_release(NE_Lock);
        lock_acquire(SW_Lock);
        kprintf("Car #%lu moves from NW to SW. Step 3 of 4 of left turn.\n", carNumber);
        lock_release(NW_Lock);
        kprintf("Car #%lu leaves SW. Step 4 of 4 of left turn.\n", carNumber);
        lock_release(SW_Lock);
        break;
      case 2:
        // Arriving from the north and turning left.
        // Moves from NW -> SW -> SE
        lock_acquire(NW_Lock);
        kprintf("Car #%lu enters NW. Step 1 of 4 of left turn.\n", carNumber);
        lock_acquire(SW_Lock);
        kprintf("Car #%lu moves from NW to SW. Step 2 of 4 of left turn.\n", carNumber);
        lock_release(NW_Lock);
        lock_acquire(SE_Lock);
        kprintf("Car #%lu moves from SW to SE. Step 3 of 4 of left turn.\n", carNumber);
        lock_release(SW_Lock);
        kprintf("Car #%lu leaves SE. Step 4 of 4 of left turn.\n", carNumber);
        lock_release(SE_Lock);
        break;
      case 3:
        // Arriving from the west and turning left.
        // Moves from SW -> SE -> NE
        lock_acquire(SW_Lock);
        kprintf("Car #%lu enters SW. Step 1 of 4 of left turn.\n", carNumber);
        lock_acquire(SE_Lock);
        kprintf("Car #%lu moves from SW to SE. Step 2 of 4 of left turn.\n", carNumber);
        lock_release(SW_Lock);
        lock_acquire(NE_Lock);
        kprintf("Car #%lu moves from SE to NE. Step 3 of 4 of left turn.\n", carNumber);
        lock_release(SE_Lock);
        kprintf("Car #%lu leaves NE. Step 4 of 4 of left turn.\n", carNumber);
        lock_release(NE_Lock);
        break;
      default: break;
    }
    decLimit();
  }

/*
* turnRight()
*
* Arguments:
*      unsigned long cardirection: the direction from which the car
*              approaches the intersection.
*      unsigned long carnumber: the car id number for printing purposes.
*
* Returns:
*      nothing.
*
* Notes:
*      This function should implement making a right turn through the
*      intersection from any direction.
*      Write and comment this function.
*/

static
void
turnRight(unsigned long carDirection,
  unsigned long carNumber)
  {
    switch (carDirection) {
      case 0:
        // Arriving from the south and turning right.
        // Moves to and from SE
        lock_acquire(SE_Lock);
        kprintf("Car #%lu enters SE. Step 1 of 2 of right turn.\n", carNumber);
        kprintf("Car #%lu leaves SE. Step 2 of 2 of right turn.\n", carNumber);
        lock_release(SE_Lock);
        break;
      case 1:
        // Arriving from the east and turning right.
        // Moves to and from NE
        lock_acquire(NE_Lock);
        kprintf("Car #%lu enters NE. Step 1 of 2 of right turn.\n", carNumber);
        kprintf("Car #%lu leaves NE. Step 2 of 2 of right turn.\n", carNumber);
        lock_release(NE_Lock);
        break;
      case 2:
        // Arriving from the north and turning right.
        // Moves to and from NW
        lock_acquire(NW_Lock);
        kprintf("Car #%lu enters NW. Step 1 of 2 of right turn.\n", carNumber);
        kprintf("Car #%lu leaves NW. Step 2 of 2 of right turn.\n", carNumber);
        lock_release(NW_Lock);
        break;
      case 3:
        // Arriving from the west and turning right.
        // Moves to and from SW
        lock_acquire(SW_Lock);
        kprintf("Car #%lu enters SW. Step 1 of 2 of right turn.\n", carNumber);
        kprintf("Car #%lu leaves SW. Step 2 of 2 of right turn.\n", carNumber);
        lock_release(SW_Lock);
        break;
      default: break;
    }
  }

/*
* approachIntersection()
*
* Arguments:
*      void * unusedpointer: currently unused.
*      unsigned long carnumber: holds car id number.
*
* Returns:
*      nothing.
*
* Notes:
*      Change this function as necessary to implement your solution. These
*      threads are created by createcars().  Each one must choose a direction
*      randomly, approach the intersection, choose a turn randomly, and then
*      complete that turn.  The code to choose a direction randomly is
*      provided, the rest is left to you to implement.  Making a turn
*      or going straight should be done by calling one of the functions
*      above.
*/

static
void
approachIntersection(void * unusedPointer,
  unsigned long carNumber)
  {
    /*
    * Avoid unused variable and function warnings.
    */

    (void) unusedPointer;

    /*
    * carDirection is a random integer between 0 and 3.
    * Defines where a car will come from.
    * 0 is south, 1 is east, 2 is north, 3 is west
    */

    int carDirection = random() % 4;

    /*
    * carTurn is a random integer between 0 and 2.
    * Defines which direction a car will travel.
    * 0 is straight, 1 is left, 2 is right
    */

    int carTurn = random() % 3;

    switch (carTurn) {
      case 0:
        // Car approaches from direction defined by carDirection and is going straight
        kprintf("Car #%lu approaches from %s and going straight.\n", carNumber, dirArray[carDirection]);
        goStraight(carDirection, carNumber);
        break;
      case 1:
        // Car approaches from direction defined by carDirection and is turning left
        kprintf("Car #%lu approaches from %s and turning left.\n", carNumber, dirArray[carDirection]);
        turnLeft(carDirection, carNumber);
        break;
      case 2:
        // Car approaches from direction defined by carDirection and is turning right
        kprintf("Car #%lu approaches from %s and turning right.\n", carNumber, dirArray[carDirection]);
        turnRight(carDirection, carNumber);
        break;
      default: break;
    }
  }

/*
* createcars()
*
* Arguments:
*      int nargs: unused.
*      char ** args: unused.
*
* Returns:
*      0 on success.
*
* Notes:
*      Driver code to start up the approachintersection() threads.  You are
*      free to modiy this code as necessary for your solution.
*/

int
createcars(int nargs,
  char ** args)
  {
    int index, error;

    /*
    * Avoid unused variable warnings.
    */

    (void) nargs;
    (void) args;

    /*
    * Initialize global Variables.
    */

    NW_Lock = lock_create("NW Lock");
    NE_Lock = lock_create("NE Lock");
    SW_Lock = lock_create("SW Lock");
    SE_Lock = lock_create("SE Lock");
    limit_Lock = lock_create("Car Limit Lock");
    enter_Lock = lock_create("Car Enter Lock");
    carLimit = 0;

    /*
    * Start NCARS approachintersection() threads.
    */

    for (index = 0; index < NCARS; index++) {

      error = thread_fork("approach intersection thread", NULL, index, approachIntersection, NULL );

      /*
      * panic() on error.
      */

      if (error) panic("approachintersection: thread_fork failed: %s\n", strerror(error));
    }
    return 0;
  }
