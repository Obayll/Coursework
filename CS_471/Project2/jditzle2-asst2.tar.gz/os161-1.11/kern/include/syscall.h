#ifndef _SYSCALL_H_
#define _SYSCALL_H_

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

struct trapframe;

int sys_reboot(int code);

pid_t sys_getpid(void);

int sys_execv(const char *prog, char **args, int *err);

pid_t sys_fork(struct trapframe *tf, int *retval);

pid_t sys_waitpid(pid_t pid, int *status, int options, int *err);

void sys__exit(int code);

#endif /* _SYSCALL_H_ */
