#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <err.h>

int
main(int argc, char *argv[]) {
	char *filename = "/testbin/add";
	char *args[4];
	pid_t pid;
	args[0] = "add";
	args[1] = "3";
	args[2] = "4";
	args[3] = NULL;
	pid = fork();
	if (pid == 0) execv(filename, argv);
	return 0;
}
