# VHDL_Basys3_PWM_7_Segment
Basys 3 with 7 segment display, switch and led

Here it is in action

https://www.youtube.com/watch?v=8txqQmskUsc
